package uz.sh.Team15.service.variant;

import uz.sh.Team15.dto.quiz.QuizDto;
import uz.sh.Team15.dto.quiz.QuizUptDto;
import uz.sh.Team15.dto.quiz.VariantDto;
import uz.sh.Team15.dto.quiz.VariantUptDto;
import uz.sh.Team15.entity.question.Quiz;
import uz.sh.Team15.entity.question.Variants;
import uz.sh.Team15.service.BaseService;
import uz.sh.Team15.service.GenericCrudService;

public interface VariantService extends GenericCrudService<
        Variants,
        VariantDto,
        VariantDto,
        VariantUptDto,
        String>, BaseService {
}
