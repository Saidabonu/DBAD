package uz.sh.Team15.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import uz.sh.Team15.entity.place.Places;

import java.util.List;
import java.util.Optional;

@Repository
public interface PlaceRepository extends JpaRepository<Places, String>, AbstractRepository{

    Optional<Places> findByNameAndRegionId(String name, String id);
    List<Places> findAllByRegionId(String id);
}
