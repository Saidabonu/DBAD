package uz.sh.Team15.mapper;

public interface Mapper {
}
