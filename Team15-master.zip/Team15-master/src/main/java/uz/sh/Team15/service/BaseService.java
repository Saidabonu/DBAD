package uz.sh.Team15.service;

public interface BaseService {

}
