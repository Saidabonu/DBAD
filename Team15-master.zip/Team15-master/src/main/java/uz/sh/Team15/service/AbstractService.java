package uz.sh.Team15.service;

import uz.sh.Team15.mapper.Mapper;
import uz.sh.Team15.repository.AbstractRepository;

public abstract class AbstractService <R extends AbstractRepository, M extends Mapper>{
    protected final R repository;
    protected final M mapper;

    public AbstractService(R repository, M mapper) {
        this.repository = repository;
        this.mapper = mapper;
    }
}
