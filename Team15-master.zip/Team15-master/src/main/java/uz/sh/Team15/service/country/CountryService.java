package uz.sh.Team15.service.country;

import uz.sh.Team15.dto.place.CountryDto;
import uz.sh.Team15.dto.place.CountryUptDto;
import uz.sh.Team15.entity.place.Country;
import uz.sh.Team15.service.BaseService;
import uz.sh.Team15.service.GenericCrudService;

public interface CountryService extends GenericCrudService<
        Country,
        CountryDto,
        CountryDto,
        CountryUptDto,
        String>, BaseService {
}
