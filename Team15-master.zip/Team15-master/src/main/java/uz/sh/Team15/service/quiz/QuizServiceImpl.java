package uz.sh.Team15.service.quiz;

import io.swagger.v3.oas.annotations.servers.Server;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import uz.sh.Team15.dto.quiz.QuizDto;
import uz.sh.Team15.dto.quiz.QuizHistoryCreateDto;
import uz.sh.Team15.dto.quiz.QuizHistoryDto;
import uz.sh.Team15.dto.quiz.QuizUptDto;
import uz.sh.Team15.entity.place.Places;
import uz.sh.Team15.entity.question.Quiz;
import uz.sh.Team15.entity.question.QuizHistory;
import uz.sh.Team15.mapper.other.QuizHistoryMapper;
import uz.sh.Team15.mapper.other.QuizMapper;
import uz.sh.Team15.repository.PlaceRepository;
import uz.sh.Team15.repository.QuizHistoryRepository;
import uz.sh.Team15.repository.QuizRepository;
import uz.sh.Team15.response.AppError;
import uz.sh.Team15.response.Data;
import uz.sh.Team15.service.AbstractService;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class QuizServiceImpl extends AbstractService<QuizRepository, QuizMapper> implements QuizService {

    private final QuizHistoryRepository quizHistoryRepository;
    private final QuizHistoryMapper quizHistoryMapper;
    private final PlaceRepository placeRepository;

    public QuizServiceImpl(QuizRepository repository, QuizMapper mapper, QuizHistoryRepository quizHistoryRepository, QuizHistoryMapper quizHistoryMapper, PlaceRepository placeRepository) {
        super(repository, mapper);
        this.quizHistoryMapper=quizHistoryMapper;
        this.quizHistoryRepository=quizHistoryRepository;
        this.placeRepository = placeRepository;
    }

    @Override
    public ResponseEntity<Data<String>> create(QuizDto createDto, String id) {
        Optional<Quiz> optionalRegion = repository.findByTitleAndPlaceId(createDto.getTitle(), id);

        if (optionalRegion.isPresent())
            return new ResponseEntity<>(new Data<>(AppError.builder().status(HttpStatus.CONFLICT)
                    .message("This quiz was already exist").build()), HttpStatus.OK);

        Quiz quiz = mapper.fromCreateDto(createDto);
        quiz.setPlaceId(id);
        repository.save(quiz);
        return new ResponseEntity<>(new Data<>(quiz.getId()), HttpStatus.OK);
    }

    @Override
    public ResponseEntity<Data<QuizDto>> update(QuizUptDto updateDto) {
        Optional<Quiz> optionalRegion = repository.findById(updateDto.getId());

        if (optionalRegion.isEmpty())
            return new ResponseEntity<>(new Data<>(AppError.builder().status(HttpStatus.CONFLICT)
                    .message("This quiz not found").build()), HttpStatus.OK);

        Quiz quiz = mapper.fromUpdateDto(updateDto);
        repository.save(quiz);
        return new ResponseEntity<>(new Data<>(mapper.toDto(quiz)), HttpStatus.OK);
    }

    @Override
    public ResponseEntity<Data<Void>> delete(String id) {
        Optional<Quiz> optionalRegion = repository.findById(id);

        if (optionalRegion.isEmpty())
            return new ResponseEntity<>(new Data<>(AppError.builder().status(HttpStatus.CONFLICT)
                    .message("This quiz not found").build()), HttpStatus.OK);

        repository.save(optionalRegion.get());
        return new ResponseEntity<>(new Data<>(true), HttpStatus.OK);
    }

    @Override
    public ResponseEntity<Data<QuizDto>> get(String id) {
        Optional<Quiz> optionalRegion = repository.findById(id);

        if (optionalRegion.isEmpty())
            return new ResponseEntity<>(new Data<>(AppError.builder().status(HttpStatus.CONFLICT)
                    .message("This quiz not found").build()), HttpStatus.OK);

        return new ResponseEntity<>(new Data<>(mapper.toDto(optionalRegion.get())), HttpStatus.OK);
    }

    @Override
    public ResponseEntity<Data<List<QuizDto>>> getAll(String id) {
        List<Quiz> optionalRegion = repository.findAllByPlaceId(id);

        if (optionalRegion.isEmpty())
            return new ResponseEntity<>(new Data<>(AppError.builder().status(HttpStatus.CONFLICT)
                    .message("This quizs not found").build()), HttpStatus.OK);

        return new ResponseEntity<>(new Data<>(mapper.toDto(optionalRegion)), HttpStatus.OK);
    }

    @Override
    public ResponseEntity<Data<Void>> quizHistory(QuizHistoryCreateDto historyDto) {
        Optional<QuizHistory> byPlaceIdAndQuizId = quizHistoryRepository.findByPlaceIdAndQuizId(historyDto.getPlaceId(), historyDto.getQuizId());
        QuizHistory quizHistory1 = quizHistoryMapper.fromCreateDto(historyDto);
        byPlaceIdAndQuizId.ifPresent(quizHistory -> {
            quizHistory1.setQuizId(byPlaceIdAndQuizId.get().getQuizId());
            quizHistory1.setPlaceId(byPlaceIdAndQuizId.get().getPlaceId());
        });
        quizHistoryRepository.save(quizHistory1);
        return new ResponseEntity<>(new Data<>(true), HttpStatus.OK);
    }

    @Override
    public ResponseEntity<Data<List<QuizHistoryDto>>> quizHistoryAll() {
        List<QuizHistory> allByPlaceId = quizHistoryRepository.findAllByUserId("userid");
        if (allByPlaceId.isEmpty())
            return new ResponseEntity<>(new Data<>(AppError.builder().status(HttpStatus.CONFLICT)
                    .message("You haven't work any quiz yet").build()), HttpStatus.OK);

        return new ResponseEntity<>(new Data<>(allByPlaceId.stream().map(this::map).toList()), HttpStatus.OK);
    }

    private QuizHistoryDto map(QuizHistory quizHistory){
        Optional<Quiz> byId = repository.findById(quizHistory.getQuizId());
        Optional<Places> byId1 = placeRepository.findById(quizHistory.getPlaceId());
        return QuizHistoryDto.builder().quizName(byId.get().getTitle())
                .placeName(byId1.get().getName())
                .score(quizHistory.getScore()).date(quizHistory.getDate()).build();
    }
}
