package uz.sh.Team15.dto.quiz;

import lombok.*;
import uz.sh.Team15.dto.Dto;

import java.time.LocalDate;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class QuizHistoryDto implements Dto {
    private String placeName;
    private String quizName;
    private Integer score;
    private LocalDate date;
}
