package uz.sh.Team15.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import uz.sh.Team15.dto.place.PlaceUptDto;
import uz.sh.Team15.dto.place.PlacesDto;
import uz.sh.Team15.response.Data;
import uz.sh.Team15.service.place.PlaceServiceImpl;

import java.util.List;

@RestController
public class PlaceController extends AbstractController<PlaceServiceImpl>{

    @Autowired
    public PlaceController(PlaceServiceImpl service) {
        super(service);
    }

    @PostMapping(PATH + "/place/")
    public ResponseEntity<Data<String>> create(@RequestBody PlacesDto dto) {
        return service.create(dto);
    }

    @PatchMapping(PATH + "/place/")
    public ResponseEntity<Data<PlacesDto>> update(@RequestBody PlaceUptDto dto) {
        return service.update(dto);
    }

    @DeleteMapping(PATH + "/place/{id}")
    public ResponseEntity<Data<Void>> delete(@PathVariable String id) {
        return service.delete(id);
    }

    @DeleteMapping(PATH + "/like/place")
    public ResponseEntity<Data<Void>> like(@RequestParam String userId,@RequestParam String placeId) {
        return service.like(userId,placeId);
    }

    @GetMapping(PATH + "/place/list/{id}")
    public ResponseEntity<Data<List<PlacesDto>>> list(@PathVariable String id) {
        return service.getAll(id);
    }

    @GetMapping(PATH + "/place/{id}")
    public ResponseEntity<Data<PlacesDto>> get(@PathVariable String id) {
        return service.get(id);
    }



}
