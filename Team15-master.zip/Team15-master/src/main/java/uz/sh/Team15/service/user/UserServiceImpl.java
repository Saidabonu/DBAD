package uz.sh.Team15.service.user;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import uz.sh.Team15.dto.user.UserCreateDto;
import uz.sh.Team15.dto.user.UserDto;
import uz.sh.Team15.dto.user.UserUpdateDto;
import uz.sh.Team15.entity.user.AuthUser;
import uz.sh.Team15.mapper.other.UserMapper;
import uz.sh.Team15.repository.UserRepository;
import uz.sh.Team15.response.AppError;
import uz.sh.Team15.response.Data;
import uz.sh.Team15.service.AbstractService;

import java.util.List;
import java.util.Optional;

@Service
public class UserServiceImpl extends AbstractService<UserRepository, UserMapper> implements UserService {
    public UserServiceImpl(UserRepository repository, UserMapper mapper) {
        super(repository, mapper);
    }

    @Override
    public ResponseEntity<Data<String>> create(UserCreateDto createDto) {
        Optional<AuthUser> optionalAuth = repository.findUserByUserNameAndPassword(createDto.getUserName(), createDto.getPassword());

        if(optionalAuth.isPresent())
            return new ResponseEntity<>(new Data<>(AppError.builder().status(HttpStatus.CONFLICT)
                    .message("This username and password already token").build()),HttpStatus.OK);

        AuthUser user = mapper.fromCreateDto(createDto);
        repository.save(user);
        return new ResponseEntity<>(new Data<>(user.getId()), HttpStatus.OK);
    }

    @Override
    public ResponseEntity<Data<UserDto>> update(UserUpdateDto updateDto) {
        Optional<AuthUser> optionalAuth = repository.findById(updateDto.getId());

        if(optionalAuth.isEmpty())
            return new ResponseEntity<>(new Data<>(AppError.builder().status(HttpStatus.CONFLICT)
                    .message("User not found").build()),HttpStatus.OK);

        AuthUser user = mapper.fromUpdateDto(updateDto);
        repository.save(user);
        return new ResponseEntity<>(new Data<>(mapper.toDto(user)), HttpStatus.OK);
    }

    @Override
    public ResponseEntity<Data<Void>> delete(String id) {
        Optional<AuthUser> user = repository.findById(id);

        if(user.isEmpty())
            return new ResponseEntity<>(new Data<>(AppError.builder().status(HttpStatus.CONFLICT)
                    .message("User not found").build()),HttpStatus.OK);

        repository.delete(user.get());
        return new ResponseEntity<>(new Data<>(true), HttpStatus.OK);
    }

    @Override
    public ResponseEntity<Data<List<UserDto>>> getAll() {
        List<AuthUser> users = repository.findAll();

        if (users.isEmpty())
            return new ResponseEntity<>(new Data<>(AppError.builder().status(HttpStatus.CONFLICT)
                    .message("Users not found").build()),HttpStatus.OK);

        return new ResponseEntity<>(new Data<>(mapper.toDto(users)), HttpStatus.OK);
    }

    @Override
    public ResponseEntity<Data<UserDto>> get(String id) {
        Optional<AuthUser> user = repository.findById(id);

        if(user.isEmpty())
            return new ResponseEntity<>(new Data<>(AppError.builder().status(HttpStatus.CONFLICT)
                    .message("User not found").build()),HttpStatus.OK);

        return new ResponseEntity<>(new Data<>(mapper.toDto(user.get())), HttpStatus.OK);
    }
}
