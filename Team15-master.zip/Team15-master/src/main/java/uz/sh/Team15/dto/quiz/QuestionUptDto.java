package uz.sh.Team15.dto.quiz;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import uz.sh.Team15.dto.GenericDto;

@Getter
@Setter
@NoArgsConstructor
public class QuestionUptDto extends GenericDto {
    private String title;
}
