package uz.sh.Team15.mapper.other;

import org.mapstruct.Mapper;
import org.springframework.stereotype.Component;
import uz.sh.Team15.dto.quiz.VariantDto;
import uz.sh.Team15.dto.quiz.VariantUptDto;
import uz.sh.Team15.entity.question.Variants;
import uz.sh.Team15.mapper.BaseMapper;

@Component
@Mapper(componentModel = "spring")
public interface VariantMapper  extends BaseMapper<
        Variants,
        VariantDto,
        VariantDto,
        VariantUptDto> {
}
