package uz.sh.Team15.dto.quiz;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import uz.sh.Team15.dto.GenericDto;

import java.time.LocalDate;

@Getter
@Setter
@NoArgsConstructor
public class QuizUptDto extends GenericDto {
    private Integer score;
    private String title;
}
