package uz.sh.Team15.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import uz.sh.Team15.entity.question.QuizHistory;

import java.util.List;
import java.util.Optional;

@Repository
public interface QuizHistoryRepository extends JpaRepository<QuizHistory, String>, AbstractRepository{
    Optional<QuizHistory> findByPlaceIdAndQuizId(String s,String id);
    List<QuizHistory> findAllByUserId( String id);
}
