package uz.sh.Team15.exception.service;

public class BadRequestException extends RuntimeException{

    public BadRequestException(String message, Throwable cause) {
        super(message, cause);
    }
}
