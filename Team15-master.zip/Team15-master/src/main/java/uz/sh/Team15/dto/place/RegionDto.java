package uz.sh.Team15.dto.place;

import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import uz.sh.Team15.dto.Dto;

@Getter
@Setter
@NoArgsConstructor
public class RegionDto implements Dto {
    private String name;
    private String description;

    @Builder(builderMethodName = "childBuilder")
    public RegionDto(String name, String description) {
        this.name = name;
        this.description = description;
    }
}
