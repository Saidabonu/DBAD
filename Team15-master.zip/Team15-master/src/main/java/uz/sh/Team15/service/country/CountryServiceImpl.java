package uz.sh.Team15.service.country;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import uz.sh.Team15.dto.place.CountryDto;
import uz.sh.Team15.dto.place.CountryUptDto;
import uz.sh.Team15.entity.place.Country;
import uz.sh.Team15.mapper.Mapper;
import uz.sh.Team15.mapper.other.CountryMapper;
import uz.sh.Team15.repository.CountryRepository;
import uz.sh.Team15.response.AppError;
import uz.sh.Team15.response.Data;
import uz.sh.Team15.service.AbstractService;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class CountryServiceImpl extends AbstractService<CountryRepository, CountryMapper> implements CountryService {

    public CountryServiceImpl(CountryRepository repository, CountryMapper mapper) {
        super(repository, mapper);
    }

    @Override
    public ResponseEntity<Data<String>> create(CountryDto createDto) {
        Optional<Country> optCountry = repository.findByName(createDto.getName());

        if(optCountry.isPresent())
            return new ResponseEntity<>(new Data<>(AppError.builder().status(HttpStatus.CONFLICT)
                    .message("This country was already token").build()),HttpStatus.OK);

        Country country = mapper.fromCreateDto(createDto);
        repository.save(country);
        return new ResponseEntity<>(new Data<>(country.getId()), HttpStatus.OK);
    }

    @Override
    public ResponseEntity<Data<CountryDto>> update(CountryUptDto updateDto) {
        Optional<Country> optCountry = repository.findById(updateDto.getId());

        if(optCountry.isEmpty())
            return new ResponseEntity<>(new Data<>(AppError.builder().status(HttpStatus.CONFLICT)
                    .message("This country not found").build()),HttpStatus.OK);

        Country country = mapper.fromUpdateDto(updateDto);
        repository.save(country);
        return new ResponseEntity<>(new Data<>(mapper.toDto(country)), HttpStatus.OK);
    }

    @Override
    public ResponseEntity<Data<Void>> delete(String id) {
        Optional<Country> optCountry = repository.findById(id);

        if(optCountry.isEmpty())
            return new ResponseEntity<>(new Data<>(AppError.builder().status(HttpStatus.CONFLICT)
                    .message("This country not found").build()),HttpStatus.OK);

        repository.delete(optCountry.get());
        return new ResponseEntity<>(new Data<>(true), HttpStatus.OK);
    }

    @Override
    public ResponseEntity<Data<List<CountryDto>>> getAll() {
        List<Country> optCountry = repository.findAll();

        if(optCountry.isEmpty())
            return new ResponseEntity<>(new Data<>(AppError.builder().status(HttpStatus.CONFLICT)
                    .message("Countries not found").build()),HttpStatus.OK);

        return new ResponseEntity<>(new Data<>(mapper.toDto(optCountry)), HttpStatus.OK);
    }

    @Override
    public ResponseEntity<Data<CountryDto>> get(String id) {
        Optional<Country> optCountry = repository.findById(id);

        if(optCountry.isEmpty())
            return new ResponseEntity<>(new Data<>(AppError.builder().status(HttpStatus.CONFLICT)
                    .message("This country not found").build()),HttpStatus.OK);

        return new ResponseEntity<>(new Data<>(mapper.toDto(optCountry.get())), HttpStatus.OK);
    }
}

