package uz.sh.Team15.service.user;

import uz.sh.Team15.dto.user.UserCreateDto;
import uz.sh.Team15.dto.user.UserDto;
import uz.sh.Team15.dto.user.UserUpdateDto;
import uz.sh.Team15.entity.user.AuthUser;
import uz.sh.Team15.service.BaseService;
import uz.sh.Team15.service.GenericCrudService;

public interface UserService extends GenericCrudService<
        AuthUser,
        UserDto,
        UserCreateDto,
        UserUpdateDto,
        String>, BaseService {
}
