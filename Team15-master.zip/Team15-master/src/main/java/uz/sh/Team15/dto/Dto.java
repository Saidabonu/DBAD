package uz.sh.Team15.dto;

public interface Dto {

}
