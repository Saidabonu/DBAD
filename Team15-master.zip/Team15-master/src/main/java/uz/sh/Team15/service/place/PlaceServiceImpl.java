package uz.sh.Team15.service.place;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import uz.sh.Team15.dto.place.PlaceUptDto;
import uz.sh.Team15.dto.place.PlacesDto;
import uz.sh.Team15.entity.place.FavoritePlace;
import uz.sh.Team15.entity.place.Places;
import uz.sh.Team15.mapper.other.PlaceMapper;
import uz.sh.Team15.repository.FavoritePlaceRepository;
import uz.sh.Team15.repository.PlaceRepository;
import uz.sh.Team15.response.AppError;
import uz.sh.Team15.response.Data;
import uz.sh.Team15.service.AbstractService;

import java.util.List;
import java.util.Optional;

@Service
public class PlaceServiceImpl  extends AbstractService<PlaceRepository, PlaceMapper> implements PlaceService {

    private final FavoritePlaceRepository placeRepository;

    public PlaceServiceImpl(PlaceRepository repository, PlaceMapper mapper, FavoritePlaceRepository placeRepository) {
        super(repository, mapper);
        this.placeRepository = placeRepository;
    }

    @Override
    public ResponseEntity<Data<String>> create(PlacesDto createDto, String regionId) {
        Optional<Places> optionalRegion = repository.findByNameAndRegionId(createDto.getName(),regionId);

        if(optionalRegion.isPresent())
            return new ResponseEntity<>(new Data<>(AppError.builder().status(HttpStatus.CONFLICT)
                    .message("This place was already exist").build()),HttpStatus.OK);

        Places place = mapper.fromCreateDto(createDto);
        place.setRegionId(regionId);
        repository.save(place);
        return new ResponseEntity<>(new Data<>(place.getId()), HttpStatus.OK);
    }

    @Override
    public ResponseEntity<Data<PlacesDto>> update(PlaceUptDto updateDto) {
        Optional<Places> optionalRegion = repository.findById(updateDto.getId());

        if(optionalRegion.isEmpty())
            return new ResponseEntity<>(new Data<>(AppError.builder().status(HttpStatus.CONFLICT)
                    .message("This place not found").build()),HttpStatus.OK);

        Places place = mapper.fromUpdateDto(updateDto);
        repository.save(place);
        return new ResponseEntity<>(new Data<>(mapper.toDto(place)), HttpStatus.OK);
    }

    @Override
    public ResponseEntity<Data<Void>> delete(String id) {
        Optional<Places> optionalRegion = repository.findById(id);

        if(optionalRegion.isEmpty())
            return new ResponseEntity<>(new Data<>(AppError.builder().status(HttpStatus.CONFLICT)
                    .message("This place not found").build()),HttpStatus.OK);

        repository.delete(optionalRegion.get());
        return new ResponseEntity<>(new Data<>(true), HttpStatus.OK);
    }

    @Override
    public ResponseEntity<Data<PlacesDto>> get(String id) {
        Optional<Places> optionalRegion = repository.findById(id);

        if(optionalRegion.isEmpty())
            return new ResponseEntity<>(new Data<>(AppError.builder().status(HttpStatus.CONFLICT)
                    .message("This place not found").build()),HttpStatus.OK);

        return new ResponseEntity<>(new Data<>(mapper.toDto(optionalRegion.get())), HttpStatus.OK);
    }

    @Override
    public ResponseEntity<Data<List<PlacesDto>>> getAll(String id) {
        List<Places> optionalRegion = repository.findAllByRegionId(id);

        if(optionalRegion.isEmpty())
            return new ResponseEntity<>(new Data<>(AppError.builder().status(HttpStatus.CONFLICT)
                    .message("This places not found").build()),HttpStatus.OK);

        return new ResponseEntity<>(new Data<>(mapper.toDto(optionalRegion)), HttpStatus.OK);
    }

    @Override
    public ResponseEntity<Data<Void>> like(String user, String place) {
        Optional<FavoritePlace> byUserIdAndPlaceId = placeRepository.findByUserIdAndPlaceId(user, place);
        byUserIdAndPlaceId.ifPresent(placeRepository::delete);
        placeRepository.save(byUserIdAndPlaceId.get());
        return new ResponseEntity<>(new Data<>(true), HttpStatus.OK);
    }
}
