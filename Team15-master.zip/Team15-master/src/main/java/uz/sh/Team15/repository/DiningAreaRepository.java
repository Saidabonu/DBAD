package uz.sh.Team15.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import uz.sh.Team15.entity.place.DiningArea;

import java.util.List;
import java.util.Optional;

@Repository
public interface DiningAreaRepository extends JpaRepository<DiningArea, String>, AbstractRepository{
    Optional<DiningArea> findByNameAndPlaceId(String name,String id);
    List<DiningArea> findAllByPlaceId(String id);
}
