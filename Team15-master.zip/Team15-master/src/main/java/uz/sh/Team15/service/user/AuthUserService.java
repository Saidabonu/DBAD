package uz.sh.Team15.service.user;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.InputStreamEntity;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import uz.sh.Team15.dto.user.AuthDto;
import uz.sh.Team15.dto.user.PasswordChangesDto;
import uz.sh.Team15.dto.user.SessionDto;
import uz.sh.Team15.dto.user.UserDto;
import uz.sh.Team15.entity.user.AuthUser;
import uz.sh.Team15.properties.ServerProperties;
import uz.sh.Team15.repository.UserRepository;
import uz.sh.Team15.response.AppError;
import uz.sh.Team15.response.Data;
import uz.sh.Team15.service.BaseService;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.Optional;

@Service
public class AuthUserService implements UserDetailsService, BaseService {

    private final UserRepository repository;
    private final PasswordEncoder encoder;
    private final ServerProperties serverProperties;
    private final ObjectMapper objectMapper;

    public AuthUserService(UserRepository userRepository, PasswordEncoder encoder, ServerProperties serverProperties, ObjectMapper objectMapper) {
        this.repository = userRepository;
        this.encoder = encoder;
        this.serverProperties = serverProperties;
        this.objectMapper = objectMapper;
    }

    public ResponseEntity<Data<AuthDto>> login (String name, String password) {
        Optional<AuthUser> auth = repository.findUserByUserNameAndPassword(name,password);
        if(auth.isEmpty()) {
            return new ResponseEntity<>(new Data<>(AppError.builder().status(HttpStatus.NOT_FOUND)
                    .message("user was not found by passport  %s".formatted(password))
                    .build()), HttpStatus.OK);
        }

        return new ResponseEntity<>(new Data<>(mapping(auth.get())),HttpStatus.OK);
    }

    public ResponseEntity<Data<AuthDto>> loginByPassword(String password,String name) {
        Optional<AuthUser> auth = repository.findUserByUserNameAndPassword(encoder.encode(password),name);
        if(auth.isEmpty())
            return new ResponseEntity<>(new Data<>(AppError.builder().status(HttpStatus.BAD_REQUEST)
                    .message("Bad Credentials").build()), HttpStatus.OK);

        return new ResponseEntity<>(new Data<>(mapping(auth.get())),HttpStatus.OK);
    }


    private AuthDto mapping(AuthUser auth) {
        return AuthDto.builder()
                .userName(auth.getUserName())
                .password(auth.getPassword())
                .build();
    }

    public ResponseEntity<Data<SessionDto>> getToken(UserDto dto) {

        try {

            HttpClient httpclient = HttpClientBuilder.create().build();
            HttpPost httppost = new HttpPost(serverProperties.getServerUrl() + "/api/v1/auth/login");
            byte[] bytes = objectMapper.writeValueAsBytes(dto);
            ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(bytes);
            httppost.setEntity(new InputStreamEntity(byteArrayInputStream));

            HttpResponse response = httpclient.execute(httppost);

            JsonNode json_auth = objectMapper.readTree(EntityUtils.toString(response.getEntity()));

            if (json_auth.has("success") && json_auth.get("success").asBoolean()) {
                JsonNode node = json_auth.get("data");
                SessionDto sessionDto = objectMapper.readValue(node.toString(), SessionDto.class);
                return new ResponseEntity<>(new Data<>(sessionDto), HttpStatus.OK);
            }
            return new ResponseEntity<>(new Data<>(objectMapper.readValue(json_auth.get("error").toString(),
                    AppError.class)), HttpStatus.OK);

        } catch (IOException e) {
            return new ResponseEntity<>(new Data<>(AppError.builder()
                    .message(e.getLocalizedMessage())
                    .status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .build()), HttpStatus.OK);
        }
    }

    public ResponseEntity<Data<SessionDto>> refreshToken(HttpServletRequest request, HttpServletResponse response) {
        return null;
    }


    @Override
    public UserDetails loadUserByUsername(String passportSerial) throws UsernameNotFoundException {
        AuthUser user = repository.findUserByUserName(passportSerial).orElseThrow(() -> {
            throw new UsernameNotFoundException("User not found");
        });
        String role= user.is_admin() ? "ADMIN" : "USER";
        return User.builder()
                .username(user.getUserName())
                .password(user.getPassword())
                .roles(role)
                .accountLocked(false)
                .accountExpired(false)
                .disabled(false)
                .credentialsExpired(false)
                .build();
    }

    public ResponseEntity<Data<Void>> changePassword(PasswordChangesDto dto) {
        Optional<AuthUser> auth = repository.findUserByIdAndPassword(dto.getId(),encoder.encode(dto.getOldPassword()));
        if(auth.isEmpty()) {
            return new ResponseEntity<>(new Data<>(AppError.builder()
                    .status(HttpStatus.BAD_REQUEST)
                    .message("Bad request")
                    .build()),HttpStatus.OK);
        }
        if(!dto.getNewPassword().equals(dto.getConfirmPassword())) {
            return new ResponseEntity<>(new Data<>(AppError.builder()
                    .status(HttpStatus.BAD_REQUEST)
                    .message("Bad request")
                    .build()),HttpStatus.OK);
        }
        auth.get().setPassword(encoder.encode(dto.getConfirmPassword()));
        repository.save(auth.get());
        return new ResponseEntity<>(new Data<>(true),HttpStatus.OK);
    }
}
