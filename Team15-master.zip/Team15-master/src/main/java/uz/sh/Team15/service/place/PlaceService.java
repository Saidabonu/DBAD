package uz.sh.Team15.service.place;

import org.springframework.http.ResponseEntity;
import uz.sh.Team15.dto.place.PlaceUptDto;
import uz.sh.Team15.dto.place.PlacesDto;
import uz.sh.Team15.entity.place.Places;
import uz.sh.Team15.response.Data;
import uz.sh.Team15.service.BaseService;
import uz.sh.Team15.service.GenericCrudService;

public interface PlaceService extends GenericCrudService<
        Places,
        PlacesDto,
        PlacesDto,
        PlaceUptDto,
        String>, BaseService {
    ResponseEntity<Data<Void>> like(String user, String place);
}
