package uz.sh.Team15.entity.place;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import uz.sh.Team15.entity.Auditable;

import javax.persistence.Entity;
import javax.persistence.Table;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "Region")
public class Region extends Auditable {
    private String name;
    private String countryId;
    private String description;
}
