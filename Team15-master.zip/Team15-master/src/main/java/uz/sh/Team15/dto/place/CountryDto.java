package uz.sh.Team15.dto.place;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import uz.sh.Team15.dto.Dto;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class CountryDto implements Dto {
    private String name;
}
