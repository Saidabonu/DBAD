package uz.sh.Team15.mapper.other;


import org.mapstruct.Mapper;
import org.springframework.stereotype.Component;
import uz.sh.Team15.dto.quiz.QuizDto;
import uz.sh.Team15.dto.quiz.QuizUptDto;
import uz.sh.Team15.entity.place.FavoritePlace;
import uz.sh.Team15.entity.question.Quiz;
import uz.sh.Team15.mapper.BaseMapper;

@Component
@Mapper(componentModel = "spring")
public interface QuizMapper extends BaseMapper<
        Quiz,
        QuizDto,
        QuizDto,
        QuizUptDto> {

}
