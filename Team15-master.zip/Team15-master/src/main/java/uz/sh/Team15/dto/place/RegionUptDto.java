package uz.sh.Team15.dto.place;

import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import uz.sh.Team15.dto.Dto;
import uz.sh.Team15.dto.GenericDto;

@Getter
@Setter
@NoArgsConstructor
public class RegionUptDto extends GenericDto {
    private String name;
    private String description;

    @Builder(builderMethodName = "childBuilder")
    public RegionUptDto(String name, String description) {
        this.name = name;
        this.description = description;
    }
}
