package uz.sh.Team15.service;

import uz.sh.Team15.dto.Dto;
import uz.sh.Team15.entity.BaseEntity;
import uz.sh.Team15.response.Data;
import org.springframework.http.ResponseEntity;

import java.io.Serializable;


public interface GenericCrudService <
        E extends BaseEntity,
        D extends Dto,
        CD extends Dto,
        UD extends Dto,
        K extends Serializable> extends GenericService<D,K>{

    default ResponseEntity<Data<K>> create(CD createDto, K id){return null;};
    default ResponseEntity<Data<K>> create(CD createDto){return null;};

    ResponseEntity<Data<D>> update(UD updateDto);

    ResponseEntity<Data<Void>> delete(K id);
}
