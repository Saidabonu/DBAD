package uz.sh.Team15.exception.service;

public class NoContentException extends RuntimeException {

    public NoContentException(String message, Throwable cause) {
        super(message, cause);
    }
}
