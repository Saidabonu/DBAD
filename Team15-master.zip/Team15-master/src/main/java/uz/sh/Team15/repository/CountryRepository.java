package uz.sh.Team15.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import uz.sh.Team15.entity.place.Country;

import java.util.Optional;

@Repository
public interface CountryRepository extends JpaRepository<Country, String>, AbstractRepository {
    Optional<Country> findByName(String name);
}
