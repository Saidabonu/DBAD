package uz.sh.Team15.dto.user;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import uz.sh.Team15.dto.Dto;
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class UserCreateDto implements Dto {
    private String firstName;
    private String lastName;
    private String userName;
    private String password;
    private boolean is_admin;
}
