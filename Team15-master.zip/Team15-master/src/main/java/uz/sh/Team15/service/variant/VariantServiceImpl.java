package uz.sh.Team15.service.variant;

import io.swagger.v3.oas.annotations.servers.Server;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import uz.sh.Team15.dto.quiz.VariantDto;
import uz.sh.Team15.dto.quiz.VariantUptDto;
import uz.sh.Team15.entity.question.Variants;
import uz.sh.Team15.mapper.other.VariantMapper;
import uz.sh.Team15.repository.VariantRepository;
import uz.sh.Team15.response.AppError;
import uz.sh.Team15.response.Data;
import uz.sh.Team15.service.AbstractService;

import java.util.List;
import java.util.Optional;

@Service
public class VariantServiceImpl extends AbstractService<VariantRepository, VariantMapper> implements VariantService {
    public VariantServiceImpl(VariantRepository repository, VariantMapper mapper) {
        super(repository, mapper);
    }

    @Override
    public ResponseEntity<Data<String>> create(VariantDto createDto, String id) {
        Optional<Variants> optionalVariant = repository.findByTextAndQuestionId(createDto.getText(),id);

        if(optionalVariant.isPresent())
            return new ResponseEntity<>(new Data<>(AppError.builder().status(HttpStatus.CONFLICT)
                    .message("This variant was already exist").build()),HttpStatus.OK);

        Variants variants = mapper.fromCreateDto(createDto);
        variants.setQuestionId(id);
        repository.save(variants);
        return new ResponseEntity<>(new Data<>(variants.getId()), HttpStatus.OK);
    }

    @Override
    public ResponseEntity<Data<VariantDto>> update(VariantUptDto updateDto) {
        Optional<Variants> optionalVariant = repository.findById(updateDto.getId());

        if(optionalVariant.isEmpty())
            return new ResponseEntity<>(new Data<>(AppError.builder().status(HttpStatus.CONFLICT)
                    .message("This variant not found").build()),HttpStatus.OK);

        Variants variants = mapper.fromUpdateDto(updateDto);
        repository.save(variants);
        return new ResponseEntity<>(new Data<>(mapper.toDto(variants)), HttpStatus.OK);
    }

    @Override
    public ResponseEntity<Data<Void>> delete(String id) {
        Optional<Variants> optionalVariant = repository.findById(id);

        if(optionalVariant.isEmpty())
            return new ResponseEntity<>(new Data<>(AppError.builder().status(HttpStatus.CONFLICT)
                    .message("This variant not found").build()),HttpStatus.OK);

        repository.delete(optionalVariant.get());
        return new ResponseEntity<>(new Data<>(true), HttpStatus.OK);
    }

    @Override
    public ResponseEntity<Data<VariantDto>> get(String id) {
        Optional<Variants> optionalVariant = repository.findById(id);

        if(optionalVariant.isEmpty())
            return new ResponseEntity<>(new Data<>(AppError.builder().status(HttpStatus.CONFLICT)
                    .message("This variant not found").build()),HttpStatus.OK);

        return new ResponseEntity<>(new Data<>(mapper.toDto(optionalVariant.get())), HttpStatus.OK);
    }

    @Override
    public ResponseEntity<Data<List<VariantDto>>> getAll(String id) {
        List<Variants> optionalVariant = repository.findAllByQuestionId(id);

        if(optionalVariant.isEmpty())
            return new ResponseEntity<>(new Data<>(AppError.builder().status(HttpStatus.CONFLICT)
                    .message("This variants not found for question").build()),HttpStatus.OK);

        return new ResponseEntity<>(new Data<>(mapper.toDto(optionalVariant)), HttpStatus.OK);
    }
}
