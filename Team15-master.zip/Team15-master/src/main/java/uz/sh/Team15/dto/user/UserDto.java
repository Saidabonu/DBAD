package uz.sh.Team15.dto.user;

import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import uz.sh.Team15.dto.Dto;
@Getter
@Setter
@NoArgsConstructor
public class UserDto implements Dto {
    private String firstName;
    private String lastName;
    private String userName;
    private String password;
    private boolean is_admin;

    @Builder(builderMethodName = "childBuilder")
    public UserDto(String firstName, String lastName, String userName, String password, boolean is_admin) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.userName = userName;
        this.password = password;
        this.is_admin = is_admin;
    }
}
