package uz.sh.Team15.service.quiz;

import org.springframework.http.ResponseEntity;
import uz.sh.Team15.dto.quiz.QuizDto;
import uz.sh.Team15.dto.quiz.QuizHistoryCreateDto;
import uz.sh.Team15.dto.quiz.QuizHistoryDto;
import uz.sh.Team15.dto.quiz.QuizUptDto;
import uz.sh.Team15.entity.question.Quiz;
import uz.sh.Team15.entity.question.QuizHistory;
import uz.sh.Team15.response.Data;
import uz.sh.Team15.service.BaseService;
import uz.sh.Team15.service.GenericCrudService;

import java.util.List;

public interface QuizService extends GenericCrudService<
        Quiz,
        QuizDto,
        QuizDto,
        QuizUptDto,
        String>, BaseService {

    ResponseEntity<Data<Void>> quizHistory(QuizHistoryCreateDto historyDto);
    ResponseEntity<Data<List<QuizHistoryDto>>> quizHistoryAll();
}
