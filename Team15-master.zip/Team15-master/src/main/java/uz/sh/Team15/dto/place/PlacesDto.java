package uz.sh.Team15.dto.place;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import uz.sh.Team15.dto.Dto;

@Getter
@Setter
@NoArgsConstructor
public class PlacesDto implements Dto {
    private String name;
    private String description;
    private String image;
}

