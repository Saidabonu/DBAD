package uz.sh.Team15.service.region;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import uz.sh.Team15.dto.place.RegionDto;
import uz.sh.Team15.dto.place.RegionUptDto;
import uz.sh.Team15.entity.place.Region;
import uz.sh.Team15.mapper.Mapper;
import uz.sh.Team15.mapper.other.RegionMapper;
import uz.sh.Team15.repository.RegionRepository;
import uz.sh.Team15.response.AppError;
import uz.sh.Team15.response.Data;
import uz.sh.Team15.service.AbstractService;

import java.util.List;
import java.util.Optional;

@Service
public class RegionServiceImpl extends AbstractService<RegionRepository, RegionMapper> implements RegionService  {

    public RegionServiceImpl(RegionRepository repository, RegionMapper mapper) {
        super(repository, mapper);
    }

    @Override
    public ResponseEntity<Data<String>> create(RegionDto createDto, String countryId) {
        Optional<Region> optCountry = repository.findByNameAndCountryId(createDto.getName(),countryId);

        if(optCountry.isPresent())
            return new ResponseEntity<>(new Data<>(AppError.builder().status(HttpStatus.CONFLICT)
                    .message("This region was already exist").build()),HttpStatus.OK);

        Region region = mapper.fromCreateDto(createDto);
        region.setCountryId(countryId);
        repository.save(region);
        return new ResponseEntity<>(new Data<>(region.getId()), HttpStatus.OK);
    }

    @Override
    public ResponseEntity<Data<RegionDto>> update(RegionUptDto updateDto) {
        Optional<Region> optCountry = repository.findById(updateDto.getId());

        if(optCountry.isEmpty())
            return new ResponseEntity<>(new Data<>(AppError.builder().status(HttpStatus.CONFLICT)
                    .message("Region not found").build()),HttpStatus.OK);

        Region region = mapper.fromUpdateDto(updateDto);
        repository.save(region);
        return new ResponseEntity<>(new Data<>(mapper.toDto(region)), HttpStatus.OK);
    }

    @Override
    public ResponseEntity<Data<Void>> delete(String id) {
        Optional<Region> optCountry = repository.findById(id);

        if(optCountry.isEmpty())
            return new ResponseEntity<>(new Data<>(AppError.builder().status(HttpStatus.CONFLICT)
                    .message("Region not found").build()),HttpStatus.OK);

        repository.delete(optCountry.get());
        return new ResponseEntity<>(new Data<>(true), HttpStatus.OK);
    }

    @Override
    public ResponseEntity<Data<List<RegionDto>>> getAll(String id) {
        List<Region> optCountry = repository.findAllByCountryId(id);

        if(optCountry.isEmpty())
            return new ResponseEntity<>(new Data<>(AppError.builder().status(HttpStatus.CONFLICT)
                    .message("Regions not found").build()),HttpStatus.OK);

        return new ResponseEntity<>(new Data<>(mapper.toDto(optCountry)), HttpStatus.OK);
    }

    @Override
    public ResponseEntity<Data<RegionDto>> get(String id) {
        Optional<Region> optCountry = repository.findById(id);

        if(optCountry.isEmpty())
            return new ResponseEntity<>(new Data<>(AppError.builder().status(HttpStatus.CONFLICT)
                    .message("Region not found").build()),HttpStatus.OK);

        return new ResponseEntity<>(new Data<>(mapper.toDto(optCountry.get())), HttpStatus.OK);
    }
}
