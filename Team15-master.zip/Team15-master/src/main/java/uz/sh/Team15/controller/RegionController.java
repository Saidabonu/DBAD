package uz.sh.Team15.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import uz.sh.Team15.dto.place.CountryDto;
import uz.sh.Team15.dto.place.CountryUptDto;
import uz.sh.Team15.dto.place.RegionDto;
import uz.sh.Team15.dto.place.RegionUptDto;
import uz.sh.Team15.response.Data;
import uz.sh.Team15.service.region.RegionServiceImpl;
import uz.sh.Team15.service.user.UserServiceImpl;

import java.util.List;

@RestController
public class RegionController extends AbstractController<RegionServiceImpl>{

    @Autowired
    public RegionController(RegionServiceImpl service) {
        super(service);
    }

    @PostMapping(PATH + "/region/")
    public ResponseEntity<Data<String>> create(@RequestBody RegionDto dto) {
        return service.create(dto);
    }

    @PatchMapping(PATH + "/region/")
    public ResponseEntity<Data<RegionDto>> update(@RequestBody RegionUptDto dto) {
        return service.update(dto);
    }

    @DeleteMapping(PATH + "/region/{id}")
    public ResponseEntity<Data<Void>> delete(@PathVariable String id) {
        return service.delete(id);
    }

    @GetMapping(PATH + "/region/list/{countryId}")
    public ResponseEntity<Data<List<RegionDto>>> list(@PathVariable String countryId) {
        return service.getAll(countryId);
    }

    @GetMapping(PATH + "/region/{id}")
    public ResponseEntity<Data<RegionDto>> get(@PathVariable String id) {
        return service.get(id);
    }
}
