package uz.sh.Team15.controller;

import io.swagger.v3.oas.annotations.Parameter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import uz.sh.Team15.dto.user.UserCreateDto;
import uz.sh.Team15.dto.user.UserDto;
import uz.sh.Team15.dto.user.UserUpdateDto;
import uz.sh.Team15.response.Data;
import uz.sh.Team15.service.user.UserServiceImpl;

import javax.validation.Valid;
import java.util.List;

@RestController
public class UserController extends AbstractController<UserServiceImpl>{
    @Autowired
    public UserController(UserServiceImpl service) {
        super(service);
    }


    @PostMapping(PATH + "/user/")
    public ResponseEntity<Data<String>> create(@RequestBody UserCreateDto dto) {
        return service.create(dto);
    }

    @PatchMapping(PATH + "/user/")
    public ResponseEntity<Data<UserDto>> update(@RequestBody UserUpdateDto dto) {
        return service.update(dto);
    }

    @DeleteMapping(PATH + "/user/{id}")
    public ResponseEntity<Data<Void>> delete(@PathVariable String id) {
        return service.delete(id);
    }

    @GetMapping(PATH + "/user/")
    public ResponseEntity<Data<List<UserDto>>> list() {
        return service.getAll();
    }

    @GetMapping(PATH + "/user/{id}")
    public ResponseEntity<Data<UserDto>> get(@PathVariable String id) {
        return service.get(id);
    }

}
