package uz.sh.Team15.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import uz.sh.Team15.entity.question.Quiz;

import java.util.List;
import java.util.Optional;

@Repository
public interface QuizRepository extends JpaRepository<Quiz, String>, AbstractRepository{
    Optional<Quiz> findByTitleAndPlaceId(String name,String id);
    List<Quiz> findAllByPlaceId(String id);
}
