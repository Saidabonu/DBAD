package uz.sh.Team15.exception.service;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class InvalidTokenException extends RuntimeException{

    public InvalidTokenException(String message, Throwable cause) {
        super(message, cause);
    }
}
