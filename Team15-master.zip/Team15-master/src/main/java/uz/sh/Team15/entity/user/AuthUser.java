package uz.sh.Team15.entity.user;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import uz.sh.Team15.entity.Auditable;

import javax.persistence.Entity;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class AuthUser extends Auditable {
    private String firstName;
    private String lastName;
    private String userName;
    private String password;
    private boolean is_admin;
}
