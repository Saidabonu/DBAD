package uz.sh.Team15.mapper.other;

import org.mapstruct.Mapper;
import org.springframework.stereotype.Component;
import uz.sh.Team15.dto.place.CountryDto;
import uz.sh.Team15.dto.place.CountryUptDto;
import uz.sh.Team15.entity.place.Country;
import uz.sh.Team15.mapper.BaseMapper;

@Component
@Mapper(componentModel = "spring")
public interface CountryMapper extends BaseMapper<
        Country,
        CountryDto,
        CountryDto,
        CountryUptDto> {
}
