package uz.sh.Team15.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import uz.sh.Team15.dto.place.DiningAreaDto;
import uz.sh.Team15.dto.place.DiningAreaUptDto;
import uz.sh.Team15.response.Data;
import uz.sh.Team15.service.diningarea.DiningAreaServiceImpl;

import java.util.List;

@RestController
public class DiningAreaController extends AbstractController<DiningAreaServiceImpl> {

    @Autowired
    public DiningAreaController(DiningAreaServiceImpl service) {
        super(service);
    }

    @PostMapping(PATH + "/diningArea/")
    public ResponseEntity<Data<String>> create(@RequestBody DiningAreaDto dto) {
        return service.create(dto);
    }

    @PatchMapping(PATH + "/diningArea/")
    public ResponseEntity<Data<DiningAreaDto>> update(@RequestBody DiningAreaUptDto dto) {
        return service.update(dto);
    }

    @DeleteMapping(PATH + "/diningArea/{id}")
    public ResponseEntity<Data<Void>> delete(@PathVariable String id) {
        return service.delete(id);
    }

    @GetMapping(PATH + "/diningArea/list/{id}")
    public ResponseEntity<Data<List<DiningAreaDto>>> list(@PathVariable String id) {
        return service.getAll(id);
    }

    @GetMapping(PATH + "/diningArea/{id}")
    public ResponseEntity<Data<DiningAreaDto>> get(@PathVariable String id) {
        return service.get(id);
    }
}
