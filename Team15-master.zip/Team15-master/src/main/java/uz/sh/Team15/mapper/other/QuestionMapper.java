package uz.sh.Team15.mapper.other;

import org.mapstruct.Mapper;
import org.springframework.stereotype.Component;
import uz.sh.Team15.dto.quiz.QuestionDto;
import uz.sh.Team15.dto.quiz.QuestionUptDto;
import uz.sh.Team15.entity.question.Question;
import uz.sh.Team15.mapper.BaseMapper;

@Component
@Mapper(componentModel = "spring")
public interface QuestionMapper  extends BaseMapper<
        Question,
        QuestionDto,
        QuestionDto,
        QuestionUptDto> {
}
