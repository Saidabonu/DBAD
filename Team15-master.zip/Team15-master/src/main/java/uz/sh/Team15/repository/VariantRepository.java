package uz.sh.Team15.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import uz.sh.Team15.entity.question.Variants;

import java.util.List;
import java.util.Optional;

@Repository
public interface VariantRepository extends JpaRepository<Variants, String>, AbstractRepository{
    Optional<Variants> findByTextAndQuestionId(String name,String id);
    List<Variants> findAllByQuestionId(String id);
}
