package uz.sh.Team15;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import uz.sh.Team15.properties.OpenApiProperties;
import uz.sh.Team15.properties.ServerProperties;

@EnableConfigurationProperties({
		OpenApiProperties.class,
		ServerProperties.class
})
@SpringBootApplication
@OpenAPIDefinition
public class InhaApplication {

	public static void main(String[] args) {
		SpringApplication.run(InhaApplication.class, args);
	}

}
