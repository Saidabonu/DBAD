package uz.sh.Team15.mapper.other;

import org.mapstruct.Mapper;
import org.springframework.stereotype.Component;
import uz.sh.Team15.dto.place.PlaceUptDto;
import uz.sh.Team15.dto.place.PlacesDto;
import uz.sh.Team15.entity.place.Places;
import uz.sh.Team15.mapper.BaseMapper;

@Component
@Mapper(componentModel = "spring")
public interface PlaceMapper extends BaseMapper<
        Places,
        PlacesDto,
        PlacesDto,
        PlaceUptDto> {
}
