package uz.sh.Team15.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import uz.sh.Team15.dto.place.CountryDto;
import uz.sh.Team15.dto.place.CountryUptDto;
import uz.sh.Team15.dto.user.UserCreateDto;
import uz.sh.Team15.dto.user.UserDto;
import uz.sh.Team15.dto.user.UserUpdateDto;
import uz.sh.Team15.response.Data;
import uz.sh.Team15.service.country.CountryServiceImpl;
import uz.sh.Team15.service.user.UserServiceImpl;

import java.util.List;

@RestController
public class CountryController extends AbstractController<CountryServiceImpl> {

    @Autowired
    public CountryController(CountryServiceImpl service) {
        super(service);
    }

    @PostMapping(PATH + "/country/")
    public ResponseEntity<Data<String>> create(@RequestBody CountryDto dto) {
        return service.create(dto);
    }

    @PatchMapping(PATH + "/country/")
    public ResponseEntity<Data<CountryDto>> update(@RequestBody CountryUptDto dto) {
        return service.update(dto);
    }

    @DeleteMapping(PATH + "/country/{id}")
    public ResponseEntity<Data<Void>> delete(@PathVariable String id) {
        return service.delete(id);
    }

    @GetMapping(PATH + "/country/")
    public ResponseEntity<Data<List<CountryDto>>> list() {
        return service.getAll();
    }

    @GetMapping(PATH + "/country/{id}")
    public ResponseEntity<Data<CountryDto>> get(@PathVariable String id) {
        return service.get(id);
    }
}
