package uz.sh.Team15.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import uz.sh.Team15.dto.quiz.QuestionDto;
import uz.sh.Team15.dto.quiz.QuestionUptDto;
import uz.sh.Team15.response.Data;
import uz.sh.Team15.service.question.QuestionServiceImpl;

import java.util.List;

@RestController
public class QuestionController extends AbstractController<QuestionServiceImpl> {

    @Autowired
    public QuestionController(QuestionServiceImpl service) {
        super(service);
    }

    @PostMapping(PATH + "/question/")
    public ResponseEntity<Data<String>> create(@RequestBody QuestionDto dto) {
        return service.create(dto);
    }

    @PatchMapping(PATH + "/question/")
    public ResponseEntity<Data<QuestionDto>> update(@RequestBody QuestionUptDto dto) {
        return service.update(dto);
    }

    @DeleteMapping(PATH + "/question/{id}")
    public ResponseEntity<Data<Void>> delete(@PathVariable String id) {
        return service.delete(id);
    }

    @GetMapping(PATH + "/question/list/{id}")
    public ResponseEntity<Data<List<QuestionDto>>> list(@PathVariable String id) {
        return service.getAll(id);
    }

    @GetMapping(PATH + "/question/{id}")
    public ResponseEntity<Data<QuestionDto>> get(@PathVariable String id) {
        return service.get(id);
    }
}
