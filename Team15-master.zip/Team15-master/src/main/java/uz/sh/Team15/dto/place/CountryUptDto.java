package uz.sh.Team15.dto.place;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import uz.sh.Team15.dto.GenericDto;

@Getter
@Setter
@NoArgsConstructor
public class CountryUptDto extends GenericDto {
    private String name;
}
