package uz.sh.Team15.service.question;

import io.swagger.v3.oas.annotations.servers.Server;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import uz.sh.Team15.dto.quiz.QuestionDto;
import uz.sh.Team15.dto.quiz.QuestionUptDto;
import uz.sh.Team15.mapper.other.QuestionMapper;
import uz.sh.Team15.mapper.other.QuizMapper;
import uz.sh.Team15.repository.QuestionRepository;
import uz.sh.Team15.repository.QuizRepository;
import uz.sh.Team15.response.Data;
import uz.sh.Team15.service.AbstractService;
import uz.sh.Team15.service.quiz.QuizService;

import java.util.List;

@Service
public class QuestionServiceImpl extends AbstractService<QuestionRepository, QuestionMapper> implements QuestionService {
    public QuestionServiceImpl(QuestionRepository repository, QuestionMapper mapper) {
        super(repository, mapper);
    }

    @Override
    public ResponseEntity<Data<String>> create(QuestionDto createDto, String id) {
        return QuestionService.super.create(createDto, id);
    }

    @Override
    public ResponseEntity<Data<QuestionDto>> update(QuestionUptDto updateDto) {
        return null;
    }

    @Override
    public ResponseEntity<Data<Void>> delete(String id) {
        return null;
    }

    @Override
    public ResponseEntity<Data<QuestionDto>> get(String id) {
        return null;
    }

    @Override
    public ResponseEntity<Data<List<QuestionDto>>> getAll(String id) {
        return QuestionService.super.getAll(id);
    }
}
