package uz.sh.Team15.mapper.other;

import org.mapstruct.Mapper;
import org.springframework.stereotype.Component;
import uz.sh.Team15.dto.Dto;
import uz.sh.Team15.dto.quiz.QuizHistoryCreateDto;
import uz.sh.Team15.dto.quiz.QuizHistoryDto;
import uz.sh.Team15.entity.question.QuizHistory;
import uz.sh.Team15.mapper.BaseMapper;

@Component
@Mapper(componentModel = "spring")
public interface QuizHistoryMapper  extends BaseMapper<
        QuizHistory,
        QuizHistoryDto,
        QuizHistoryCreateDto,
        Dto> {
}
