package uz.sh.Team15.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import uz.sh.Team15.entity.question.Question;

@Repository
public interface QuestionRepository extends JpaRepository<Question, String>, AbstractRepository{
}
