package uz.sh.Team15.service.diningarea;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import uz.sh.Team15.dto.place.DiningAreaDto;
import uz.sh.Team15.dto.place.DiningAreaUptDto;
import uz.sh.Team15.entity.place.DiningArea;
import uz.sh.Team15.entity.place.Places;
import uz.sh.Team15.mapper.other.DiningAreaMapper;
import uz.sh.Team15.repository.DiningAreaRepository;
import uz.sh.Team15.response.AppError;
import uz.sh.Team15.response.Data;
import uz.sh.Team15.service.AbstractService;

import java.util.List;
import java.util.Optional;

@Service
public class DiningAreaServiceImpl extends AbstractService<DiningAreaRepository, DiningAreaMapper> implements DiningAreaService {
    public DiningAreaServiceImpl(DiningAreaRepository repository, DiningAreaMapper mapper) {
        super(repository, mapper);
    }

    @Override
    public ResponseEntity<Data<String>> create(DiningAreaDto createDto, String placeId) {
        Optional<DiningArea> optionalRegion = repository.findByNameAndPlaceId(createDto.getName(),placeId);

        if(optionalRegion.isPresent())
            return new ResponseEntity<>(new Data<>(AppError.builder().status(HttpStatus.CONFLICT)
                    .message("This dining area was already exist").build()),HttpStatus.OK);

        DiningArea diningArea = mapper.fromCreateDto(createDto);
        diningArea.setPlaceId(placeId);
        repository.save(diningArea);
        return new ResponseEntity<>(new Data<>(diningArea.getId()), HttpStatus.OK);
    }

    @Override
    public ResponseEntity<Data<DiningAreaDto>> update(DiningAreaUptDto updateDto) {
        Optional<DiningArea> optionalRegion = repository.findById(updateDto.getId());

        if(optionalRegion.isEmpty())
            return new ResponseEntity<>(new Data<>(AppError.builder().status(HttpStatus.CONFLICT)
                    .message("This dining area not fount").build()),HttpStatus.OK);

        DiningArea diningArea = mapper.fromUpdateDto(updateDto);
        repository.save(diningArea);
        return new ResponseEntity<>(new Data<>(mapper.toDto(diningArea)), HttpStatus.OK);
    }

    @Override
    public ResponseEntity<Data<Void>> delete(String id) {
        Optional<DiningArea> optionalRegion = repository.findById(id);

        if(optionalRegion.isEmpty())
            return new ResponseEntity<>(new Data<>(AppError.builder().status(HttpStatus.CONFLICT)
                    .message("This dining area not fount").build()),HttpStatus.OK);

        repository.delete(optionalRegion.get());
        return new ResponseEntity<>(new Data<>(true), HttpStatus.OK);
    }

    @Override
    public ResponseEntity<Data<DiningAreaDto>> get(String id) {
        Optional<DiningArea> optionalRegion = repository.findById(id);

        if(optionalRegion.isEmpty())
            return new ResponseEntity<>(new Data<>(AppError.builder().status(HttpStatus.CONFLICT)
                    .message("This dining area not fount").build()),HttpStatus.OK);

        return new ResponseEntity<>(new Data<>(mapper.toDto(optionalRegion.get())), HttpStatus.OK);
    }


    @Override
    public ResponseEntity<Data<List<DiningAreaDto>>> getAll(String id) {
        List<DiningArea> optionalRegion = repository.findAllByPlaceId(id);

        if(optionalRegion.isEmpty())
            return new ResponseEntity<>(new Data<>(AppError.builder().status(HttpStatus.CONFLICT)
                    .message("This dining areas not fount").build()),HttpStatus.OK);

        return new ResponseEntity<>(new Data<>(mapper.toDto(optionalRegion)), HttpStatus.OK);
    }
}
