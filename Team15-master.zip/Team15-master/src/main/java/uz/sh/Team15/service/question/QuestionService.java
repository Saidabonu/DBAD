package uz.sh.Team15.service.question;

import uz.sh.Team15.dto.quiz.QuestionDto;
import uz.sh.Team15.dto.quiz.QuestionUptDto;
import uz.sh.Team15.dto.quiz.QuizDto;
import uz.sh.Team15.dto.quiz.QuizUptDto;
import uz.sh.Team15.entity.question.Question;
import uz.sh.Team15.entity.question.Quiz;
import uz.sh.Team15.service.BaseService;
import uz.sh.Team15.service.GenericCrudService;

public interface QuestionService  extends GenericCrudService<
        Question,
        QuestionDto,
        QuestionDto,
        QuestionUptDto,
        String>, BaseService {
}
