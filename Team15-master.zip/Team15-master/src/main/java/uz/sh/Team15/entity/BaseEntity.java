package uz.sh.Team15.entity;

public interface BaseEntity {

}
