package uz.sh.Team15.service.region;

import uz.sh.Team15.dto.place.RegionDto;
import uz.sh.Team15.dto.place.RegionUptDto;
import uz.sh.Team15.entity.place.Region;
import uz.sh.Team15.service.BaseService;
import uz.sh.Team15.service.GenericCrudService;

public interface RegionService extends GenericCrudService<
        Region,
        RegionDto,
        RegionDto,
        RegionUptDto,
        String>, BaseService {
}
