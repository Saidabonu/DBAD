package uz.sh.Team15.dto.place;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import uz.sh.Team15.dto.Dto;
import uz.sh.Team15.dto.GenericDto;

@Getter
@Setter
@NoArgsConstructor
public class DiningAreaUptDto extends GenericDto {
    private String name;
}
