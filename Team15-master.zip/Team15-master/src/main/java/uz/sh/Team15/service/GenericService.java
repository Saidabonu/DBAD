package uz.sh.Team15.service;

import uz.sh.Team15.dto.Dto;
import uz.sh.Team15.response.Data;
import org.springframework.http.ResponseEntity;

import java.io.Serializable;
import java.util.List;

public interface GenericService <
        D extends Dto,
        K extends Serializable> {

    default ResponseEntity<Data<List <D>>> getAll(){return null;};
    default ResponseEntity<Data<List <D>>> getAll(K id){return null;};
    ResponseEntity<Data<D>> get (K id);
}
