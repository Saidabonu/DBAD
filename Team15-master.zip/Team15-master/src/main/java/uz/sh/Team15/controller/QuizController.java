package uz.sh.Team15.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import uz.sh.Team15.dto.quiz.QuizDto;
import uz.sh.Team15.dto.quiz.QuizHistoryCreateDto;
import uz.sh.Team15.dto.quiz.QuizHistoryDto;
import uz.sh.Team15.dto.quiz.QuizUptDto;
import uz.sh.Team15.response.Data;
import uz.sh.Team15.service.quiz.QuizServiceImpl;

import java.util.List;

@RestController
public class QuizController extends AbstractController<QuizServiceImpl>{

    @Autowired
    public QuizController(QuizServiceImpl service) {
        super(service);
    }

    @PostMapping(PATH + "/quiz/")
    public ResponseEntity<Data<String>> create(@RequestBody QuizDto dto) {
        return service.create(dto);
    }

    @PatchMapping(PATH + "/quiz/")
    public ResponseEntity<Data<QuizDto>> update(@RequestBody QuizUptDto dto) {
        return service.update(dto);
    }

    @DeleteMapping(PATH + "/quiz/{id}")
    public ResponseEntity<Data<Void>> delete(@PathVariable String id) {
        return service.delete(id);
    }

    @GetMapping(PATH + "/quiz/list/{id}")
    public ResponseEntity<Data<List<QuizDto>>> list(@PathVariable String id) {
        return service.getAll(id);
    }

    @GetMapping(PATH + "/quiz/{id}")
    public ResponseEntity<Data<QuizDto>> get(@PathVariable String id) {
        return service.get(id);
    }

    @PostMapping(PATH + "/quizHistory/{id}")
    public ResponseEntity<Data<Void>> quizHistory(@RequestBody QuizHistoryCreateDto dto) {
        return service.quizHistory(dto);
    }

    @GetMapping(PATH + "/quizHistory")
    public ResponseEntity<Data<List<QuizHistoryDto>>> quizHistoryAll() {
        return service.quizHistoryAll();
    }
}
