package uz.sh.Team15.dto.user;

import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import uz.sh.Team15.dto.Dto;
import uz.sh.Team15.dto.GenericDto;

import javax.validation.constraints.NotBlank;

@Getter
@Setter
@NoArgsConstructor
public class UserUpdateDto extends GenericDto {
    private String firstName;
    private String lastName;
    private String userName;
    private String password;

    @Builder(builderMethodName = "childBuilder")
    public UserUpdateDto(@NotBlank(message = "id not be null") String id, String firstName, String lastName, String userName, String password) {
        super(id);
        this.firstName = firstName;
        this.lastName = lastName;
        this.userName = userName;
        this.password = password;
    }
}
