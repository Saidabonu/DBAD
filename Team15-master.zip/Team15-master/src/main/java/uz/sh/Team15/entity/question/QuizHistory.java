package uz.sh.Team15.entity.question;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import uz.sh.Team15.entity.Auditable;

import javax.persistence.Entity;
import javax.persistence.Table;
import java.time.LocalDate;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "Quiz_history")
public class QuizHistory extends Auditable {
    private String userId;
    private String placeId;
    private String quizId;
    private LocalDate date;
    private Integer score;
}
