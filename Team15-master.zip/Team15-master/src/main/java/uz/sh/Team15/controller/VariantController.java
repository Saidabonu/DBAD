package uz.sh.Team15.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import uz.sh.Team15.dto.place.CountryDto;
import uz.sh.Team15.dto.place.CountryUptDto;
import uz.sh.Team15.dto.quiz.VariantDto;
import uz.sh.Team15.dto.quiz.VariantUptDto;
import uz.sh.Team15.response.Data;
import uz.sh.Team15.service.question.QuestionServiceImpl;
import uz.sh.Team15.service.variant.VariantServiceImpl;

import java.util.List;

@RestController
public class VariantController extends AbstractController<VariantServiceImpl>{

    @Autowired
    public VariantController(VariantServiceImpl service) {
        super(service);
    }

    @PostMapping(PATH + "/variant/")
    public ResponseEntity<Data<String>> create(@RequestBody VariantDto dto) {
        return service.create(dto);
    }

    @PatchMapping(PATH + "/variant/")
    public ResponseEntity<Data<VariantDto>> update(@RequestBody VariantUptDto dto) {
        return service.update(dto);
    }

    @DeleteMapping(PATH + "/variant/{id}")
    public ResponseEntity<Data<Void>> delete(@PathVariable String id) {
        return service.delete(id);
    }

    @GetMapping(PATH + "/variant/list/{id}")
    public ResponseEntity<Data<List<VariantDto>>> list(@PathVariable String id) {
        return service.getAll(id);
    }

    @GetMapping(PATH + "/variant/{id}")
    public ResponseEntity<Data<VariantDto>> get(@PathVariable String id) {
        return service.get(id);
    }
}
