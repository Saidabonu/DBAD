package uz.sh.Team15.dto.quiz;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import uz.sh.Team15.dto.Dto;

import java.time.LocalDate;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class QuizHistoryCreateDto implements Dto {
    private String placeId;
    private String quizId;
    private Integer score;
    private LocalDate date;
}
