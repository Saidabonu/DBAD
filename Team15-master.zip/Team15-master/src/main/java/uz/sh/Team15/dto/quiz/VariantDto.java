package uz.sh.Team15.dto.quiz;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import uz.sh.Team15.dto.Dto;

@Getter
@Setter
@NoArgsConstructor
public class VariantDto implements Dto {
    private String text;
}
