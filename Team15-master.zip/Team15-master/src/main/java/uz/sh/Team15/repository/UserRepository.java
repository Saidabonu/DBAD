package uz.sh.Team15.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import uz.sh.Team15.entity.user.AuthUser;

import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<AuthUser, String>, AbstractRepository{

    Optional<AuthUser> findUserByUserNameAndPassword(String username, String password);
    Optional<AuthUser> findUserByPassword( String password);
    Optional<AuthUser> findUserByUserName(String username);
    Optional<AuthUser> findUserByIdAndPassword(String id,String password);
}
