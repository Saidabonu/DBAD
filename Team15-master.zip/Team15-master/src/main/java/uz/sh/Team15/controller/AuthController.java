package uz.sh.Team15.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import uz.sh.Team15.dto.user.AuthDto;
import uz.sh.Team15.dto.user.PasswordChangesDto;
import uz.sh.Team15.dto.user.SessionDto;
import uz.sh.Team15.dto.user.UserDto;
import uz.sh.Team15.response.Data;
import uz.sh.Team15.service.user.AuthUserService;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@RestController
public class AuthController extends AbstractController<AuthUserService>{
    public AuthController(AuthUserService service) {
        super(service);
    }

    @RequestMapping(value = PATH + "/auth/token", method = RequestMethod.POST)
    public ResponseEntity<Data<SessionDto>> getToken(@RequestBody UserDto dto) {
        return service.getToken(dto);
    }

    @RequestMapping(value = PATH + "/auth/refresh-token", method = RequestMethod.GET)
    public ResponseEntity<Data<SessionDto>> refreshToken(HttpServletRequest request, HttpServletResponse response) {
        return service.refreshToken(request, response);
    }

    @RequestMapping(value = PATH + "/auth/login", method = RequestMethod.POST)
    public ResponseEntity<Data<AuthDto>> loginByPassword(UserDto dto) {
        return service.loginByPassword(dto.getPassword(), dto.getUserName());
    }

    @RequestMapping(value = PATH + "/employee/change_password",method = RequestMethod.PATCH)
    public ResponseEntity<Data<Void>> changePassword(@RequestBody PasswordChangesDto dto) {
        return service.changePassword(dto);
    }



}
