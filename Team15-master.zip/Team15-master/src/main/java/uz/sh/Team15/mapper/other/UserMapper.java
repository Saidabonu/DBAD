package uz.sh.Team15.mapper.other;

import org.mapstruct.Mapper;
import org.springframework.stereotype.Component;
import uz.sh.Team15.dto.user.UserCreateDto;
import uz.sh.Team15.dto.user.UserDto;
import uz.sh.Team15.dto.user.UserUpdateDto;
import uz.sh.Team15.entity.user.AuthUser;
import uz.sh.Team15.mapper.BaseMapper;

@Component
@Mapper(componentModel = "spring")
public interface UserMapper extends BaseMapper<
        AuthUser,
        UserDto,
        UserCreateDto,
        UserUpdateDto> {
}
