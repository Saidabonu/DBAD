package uz.sh.Team15.service.diningarea;

import uz.sh.Team15.dto.place.DiningAreaDto;
import uz.sh.Team15.dto.place.DiningAreaUptDto;
import uz.sh.Team15.entity.place.DiningArea;
import uz.sh.Team15.service.BaseService;
import uz.sh.Team15.service.GenericCrudService;

public interface DiningAreaService extends GenericCrudService<
        DiningArea,
        DiningAreaDto,
        DiningAreaDto,
        DiningAreaUptDto,
        String>, BaseService {
}
